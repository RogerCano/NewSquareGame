#include "SDL.h"
#pragma comment (lib,"SDL2.lib")
#pragma comment (lib,"SDL2main.lib")
#define SCREEN_WEIGHT 1080
#define SCREEN_HEIGHT 720
#define SPEED 1
#define SPEED2 1
#define RECT_SIZE 100
#define PROJ_SIZE 15
int main(int argc, char* argv[])
{

	SDL_Init(SDL_INIT_EVERYTHING);

	SDL_Window* window;
	SDL_Event e;
	SDL_Renderer* renderer;

	SDL_Rect rect;
	rect.h = rect.w = RECT_SIZE;
	rect.x = (SCREEN_WEIGHT / 2) - (RECT_SIZE / 2);
	rect.y = (SCREEN_HEIGHT / 2) - (RECT_SIZE / 2);

	SDL_Rect proj;
	proj.h = PROJ_SIZE;
	proj.w = PROJ_SIZE + 10;


	window = SDL_CreateWindow("My Window Game",
		SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
		SCREEN_WEIGHT, SCREEN_HEIGHT, SDL_WINDOW_RESIZABLE);

	renderer = SDL_CreateRenderer(window, -1, 0);

	bool IsFiring;

	while (1)
	{
		SDL_PollEvent(&e);
		if (e.type == SDL_QUIT || e.key.keysym.scancode == SDL_SCANCODE_ESCAPE) { break; }

		else if (e.type == SDL_KEYDOWN && e.key.keysym.scancode == SDL_SCANCODE_UP) {
			rect.y -= SPEED;
			
		}

		else if (e.type == SDL_KEYDOWN && e.key.keysym.scancode == SDL_SCANCODE_DOWN) {
			rect.y += SPEED;
			
		}

		else if (e.type == SDL_KEYDOWN && e.key.keysym.scancode == SDL_SCANCODE_RIGHT) {
			rect.x += SPEED;
			
		}

		else if (e.type == SDL_KEYDOWN && e.key.keysym.scancode == SDL_SCANCODE_LEFT) {
			rect.x -= SPEED;
			
		}

		else if (e.type == SDL_KEYDOWN && e.key.keysym.scancode == SDL_SCANCODE_R) {
			rect.x = SCREEN_WEIGHT / 2;
			
		}
		else if (e.type == SDL_KEYDOWN && e.key.keysym.scancode == SDL_SCANCODE_SPACE){
			IsFiring = true;
			proj.x = (SCREEN_WEIGHT / 2) - (RECT_SIZE / 2);
			proj.y = (SCREEN_HEIGHT / 2) + (RECT_SIZE / 4);
		}

		

		SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
		SDL_RenderClear(renderer);

		SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
		SDL_RenderFillRect(renderer, &rect);

		if (IsFiring == true) {
			SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);
			SDL_RenderFillRect(renderer, &proj);
			proj.x += SPEED2;

		//SDL_RenderPresent(renderer);

		
			
			//IsFiring = false;
		}
		SDL_RenderPresent(renderer);
	}


	SDL_DestroyWindow(window);
	SDL_DestroyRenderer(renderer);

	SDL_Quit();
	return 0;
}